Role Name
=========

This role checks the devices associated to the user. Search the associated devices with user id. Get details of associtaed devices then sends SOAP body to axl api's of CISCO and updates the description ,ASCII details of phone and its associated lines as per new requeste description.
And emails to cisco team with details on success and failure
SUCCESS: ones the phone with given description updated successfully
FAILURE: if no phone exists with given description

Requirements
------------

N/A

Role Variables
--------------

ccum_hostname: 
user: 
password:
phone_userid:
new_description:
from_email_id:
to_email_id:
ticket_id:

Dependencies
------------

A list of other roles hosted on Galaxy should go here, plus any details in regards to parameters that may need to be set for other roles, or variables that are used from other roles.

Example Playbook
----------------

---
- hosts: localhost
  gather_facts: false
  roles:
    - ansible-cbi-idop-voice-role-telephone_name_update

License
-------

N/A

Author Information
------------------

IDOP Integration Team
[DL-IT-ACN-IDOP](acnidop@cbrands.com)
