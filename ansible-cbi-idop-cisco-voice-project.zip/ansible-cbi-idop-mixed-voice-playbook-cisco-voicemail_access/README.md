Role Name
=========

This role checks if user is on Cisco unity. search the user on Cisco unity with aduser and if user is already there then only reset the password and send email to user. if user is already not present then add the user first then reset the pin and mail will be sent to the user and also updating the worknotes in ticket. 
Requirements
------------

N/A

Role Variables
--------------

ad_user: 
location: 
to_email_id: 
from_email_id: 
firstName:
incidentNumber: 

Dependencies
------------

A list of other roles hosted on Galaxy should go here, plus any details in regards to parameters that may need to be set for other roles, or variables that are used from other roles.

Example Playbook
----------------

---
- hosts: localhost
  gather_facts: false
  roles:
    - voice

License
-------

N/A

Author Information
------------------

IDOP Integration Team
[DL-IT-ACN-IDOP](acnidop@cbrands.com)
