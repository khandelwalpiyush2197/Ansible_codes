Role Name
=========

This role checks if user is having access on Dev and Stage Tidal environment. search the user on Tidal environment with full name. if user is present on the envt the access will be get revoked if not then no action will be required. and the mail will be sent to the Tidal Team DL also updating the worknotes in ticket. 
Requirements
------------

N/A

Role Variables
--------------

username: 
incidentNumber:
to_email:
from_email:

Dependencies
------------

A list of other roles hosted on Galaxy should go here, plus any details in regards to parameters that may need to be set for other roles, or variables that are used from other roles.

Example Playbook
----------------

---
- hosts: localhost
  gather_facts: false
  roles:
    - tidal

License
-------

N/A

Author Information
------------------

IDOP Integration Team
[DL-IT-ACN-IDOP](acnidop@cbrands.com)
