sqlplus "'$1'"/$2@GPORACRS01-SCAN:1521/TES1PD.cbi.net @tidal_job.sql;
exit

