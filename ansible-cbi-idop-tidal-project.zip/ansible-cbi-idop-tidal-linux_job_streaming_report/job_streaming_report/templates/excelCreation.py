import sys
import pandas as pd
import openpyxl
import jpype
import asposecells
jpype.startJVM()
from asposecells.api import Workbook, FileFormatType, PdfSaveOptions
from openpyxl import load_workbook
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side
from openpyxl.styles import Font

date = sys.argv[1]
csvPath = "/tmp/tidal_summary.csv"
excelPath = "/tmp/tidal_summary.xlsx"
pdfPath = "/tmp/Tidal Daily Summary - Critical Path Report.pdf"
#########To convert csv to xlsx
read_file = pd.read_csv(csvPath)
read_file.to_excel(excelPath, index=None, header=True)

#########To insert new rows

# Instantiate a Workbook object by excel file path
workbook = Workbook(excelPath)

# Access the first worksheet in the Excel file
worksheet = workbook.getWorksheets().get(0)

# Insert a row into the worksheet at 3rd position
worksheet.getCells().insertRows(0,4)

# Save the modified Excel file in default (that is Excel 2003) format
workbook.save(excelPath)


#########To delete extra sheet


workbook=openpyxl.load_workbook(excelPath)

std=workbook.get_sheet_by_name('Evaluation Warning')

workbook.remove_sheet(std)

workbook.save(excelPath)


######### To give heading


#Specify the Workbook

wb_append = load_workbook(excelPath)

sheet = wb_append.active

value="as of "+ date + " EST"
#Writing to Cell

sheet["A1"] = "Critical Path Processing"
sheet["A2"] = "Tidal Daily Summary - Critical Path Report"
sheet["A3"] = value
#Save the operation

wb_append.save(excelPath)


######### To merge the cells


wb_append = load_workbook(excelPath)
sheet = wb_append.active

sheet.merge_cells('A1:I1')
sheet.merge_cells('A2:I2')
sheet.merge_cells('A3:I3')
sheet.merge_cells('A4:I4')

cell = sheet.cell(row=1, column=1)
cell.alignment = Alignment(horizontal='center', vertical='center')
cell.font = Font(bold=True)

cell2 = sheet.cell(row=2, column=1)
cell2.alignment = Alignment(horizontal='center', vertical='center')
cell2.font = Font(bold=True)

cell3 = sheet.cell(row=3, column=1)
cell3.alignment = Alignment(horizontal='center', vertical='center')
cell3.font = Font(bold=True)
wb_append.save(excelPath)

########## To increase column width

worksheet = openpyxl.load_workbook(excelPath)
sheet = worksheet.active

sheet.column_dimensions['A'].width = 30
sheet.column_dimensions['B'].width = 30
sheet.column_dimensions['C'].width = 20
sheet.column_dimensions['D'].width = 25
sheet.column_dimensions['E'].width = 25
sheet.column_dimensions['F'].width = 25
sheet.column_dimensions['G'].width = 30
sheet.column_dimensions['H'].width = 28
sheet.column_dimensions['I'].width = 30

worksheet.save(excelPath)

########## To add table border

wb=load_workbook(excelPath)
ws=wb['Sheet1']
top=Side(border_style='thin')
bottom=Side(border_style='thin')
left=Side(border_style='thin')
right=Side(border_style='thin')
border=Border(top=top,bottom=bottom,left=left,right=right)
range=ws['A5':'I18']
for cell in range:
    for x in cell:
        x.border=border
wb.save(excelPath)
########## To Color End time column

path_to_excel=excelPath
exemple=openpyxl.load_workbook(path_to_excel)
ws = exemple['Sheet1']
from openpyxl.styles import PatternFill
green = PatternFill(patternType='solid', fgColor='22e638')
red = PatternFill(patternType='solid', fgColor='f71111')
for column in ws['J']:
  if column.value == " Green":
    cell=str(column.row)
    endTime="C"+cell
    c = ws[endTime]
    c.fill = green
    status="I"+cell
    s = ws[status]
    s.fill = green
    
  elif column.value == " Red":
    cell=str(column.row)
    endTime="C"+cell
    c = ws[endTime]
    c.fill = red
    status="I"+cell
    s = ws[status]
    s.fill = red 
ws.column_dimensions['J'].hidden= True
exemple.save(path_to_excel)

########## To centre align the text

wb_append = load_workbook(excelPath)

sheet = wb_append.active
range=sheet['C6':'I18']
for cell in range:
    for x in cell:
        x.alignment = Alignment(horizontal='center')

wb_append.save(excelPath)

########### To conver to pdf

workbook = Workbook(excelPath)
saveOptions = PdfSaveOptions()
saveOptions.setOnePagePerSheet(True)
workbook.save(pdfPath, saveOptions)

jpype.shutdownJVM()
