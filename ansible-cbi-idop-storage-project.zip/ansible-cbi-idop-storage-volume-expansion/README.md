Role Name
=========
checks
This role checks the Aggregate value and if aggregate is less then 80% then it is only going to expand the volume and volume deatils will be sent to the Team and updated in work notes.

Requirements
------------

N/A

Role Variables
--------------

hostname: 
vol_name:
ticketnumber:
to_email:
from_email:

Dependencies
------------

A list of other roles hosted on Galaxy should go here, plus any details in regards to parameters that may need to be set for other roles, or variables that are used from other roles.

Example Playbook
----------------

---
- hosts: localhost
  gather_facts: false
  roles:
    - volume_expansion

License
-------

N/A

Author Information
------------------

IDOP Integration Team
[DL-IT-ACN-IDOP](acnidop@cbrands.com)
