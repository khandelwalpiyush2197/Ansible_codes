Role Name
=========
This Ansible role is used to perform health check on Storage clusters and will generate the report of the clusters to the mail id provided.

Requirements
------------
NA
Role Variables
--------------
```
---
hostname_list: 
admin_username:
admin_password:
to_email_id: 
from_email_id: 

```

Dependencies
------------
N/A


Example Playbook
----------------
```
---
- hosts: localhost
  roles:
    - Storage_healthcheck
```


License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
