Playbook Name
=============
ansible-cbi-idop-mixed-windows-playbook-java-discovery.yml
This playbook will check the java details present in the windows servers. Check if file with name java and .exe is present in either fo these folders: C:\Program Files (x86),C:\Program Files.
And csv file generated with the details of servers with java details and email will be send to windows DL.

1) Server Name
2) Server OS
3) Server OS Version
4) Architecture
5) JAVA Path

 included throttle:1 to make sure each server is run at a time so the output comes in a regular fashion.
Requirements
-----------

For mail module to be included in the playbook "community.general" collection needs to be added in the requirements.yml

collections/requirements.yml

Role Variables
--------------

to_email_id: itacnwintel@cbrands.com
from_email_id: itacnwintel@cbrands.com

Dependencies
------------

N/A

Example Playbook
----------------

```
---
- name: JAVA Discovery for Windows
  hosts: all
  tasks:
    - name:

```
License
-------

N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com) 

