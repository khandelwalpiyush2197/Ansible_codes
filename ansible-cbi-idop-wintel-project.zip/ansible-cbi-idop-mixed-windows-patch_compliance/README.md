Playbook Name
=============
ansible-cbi-idop-mixed-windows-patch_compliance.yml
This playbook will check the patch compliance for all the AWS windows server.Consolidated detail email will be send to windows DL.

1) Server Name
2) Hotfix ID
3) Updated date

 included throttle:1 to make sure each server is run at a time so the output comes in a regular fashion.

Requirements
-----------

For mail module to be included in the playbook "community.general" collection needs to be added in the requirements.yml

collections/requirements.yml

Role Variables
--------------

to_email_id: itacnwintel@cbrands.com
from_email_id: itacnwintel@cbrands.com

Dependencies
------------

N/A

Example Playbook
----------------

```
---
- name: patch compliance for AWS windows
  hosts: all
  tasks:
    - name:

```
License
-------

N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com) 

