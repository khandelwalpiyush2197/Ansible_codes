param(
    [Parameter(Mandatory=$True)]
    [int]$delete_file_age
    )
$OFile = "C:\TEMP\IIS_log\logfile.txt"
If ((Test-Path $OFile) -eq $true){ Remove-Item $OFile }
$log_path = Get-Content 'C:\TEMP\IIS_Log_Shared_Path.txt' | Select -Skip 1
#$log_path="\\CBIGDC-DFTPF901\IISLogTest"
$Today = Get-Date
$delete_file_age
$Daytoinspect=$Today.AddDays(-$delete_file_age)
$LogExt = "*.log"
foreach($path in $log_path)
{
Resolve-Path $path
$path
Test-Path $path
#New-PSDrive -Name Y -PSProvider "FileSystem" -Root $path
#$Old_Files = Get-PSDrive Y 
#$Old_Files.Root
#$Files = Get-ChildItem -Path $Old_Files.Root -Include $LogExt -Recurse | Where { $_.LastWriteTime -le "$Daytoinspect" }
$Files = Get-ChildItem -Path $path -Include $LogExt -Recurse | Where { $_.LastWriteTime -le "$Daytoinspect" }
if($Files -ne $NULL)
{
Write-Output "File found in $path , we are deleting the files" >> $OFile
add-content  $Ofile "$Files"
Remove-Item $Files
}
else
{
 Write-Output "Script Ends- No files older then $delete_file_age days found in $path" >> $OFile
}
}