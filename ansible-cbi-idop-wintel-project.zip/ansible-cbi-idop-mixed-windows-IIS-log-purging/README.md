Role Name
=========

ansible-cbi-idop-mixed-windows-IIS-log-purging
This ansible role can be use to remove IIS log files which are older then the days passes to  delete_file_age days variable.


Requirements
------------

N/A

Role Variables
--------------
---
delete_file_age: 


Dependencies
------------

N/A

Example Playbook
----------------

---
- name: fetch user details
  hosts: all
  tasks:
    - name:

...


License
-------

N/A

Author Information
------------------

IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)


