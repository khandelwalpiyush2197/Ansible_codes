Playbook Name
=============
ansible-cbi-idop-mixed-windows-service-restart.yml
Monitoring Windows service status playbook will check the current status of the service.

1) Check if the service exists on the server and disply the appropriate message.
2) If service exists and reachable, then service current status and  its state message will be displayed.
3) if the service exists but unreachable , then service current status and  its state message will be displayed.

Requirements
-----------

N/A

Role Variables
--------------

service_name: <service_name>

Dependencies
------------

N/A

Example Playbook
----------------

```
---
- name: service status check
  hosts: all
  tasks:
    - name:

```
License
-------

N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com) 


