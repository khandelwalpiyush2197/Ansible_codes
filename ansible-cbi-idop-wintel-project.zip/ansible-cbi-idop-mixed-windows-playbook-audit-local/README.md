Role Name
=========

ansible-cbi-idop-mixed-windows-auditing-local
This ansible role can be use to generate csv report from windows server with below details and send mail to user with attached file.
1. User name
2. Group name
3. Server name

Requirements
------------

N/A

Role Variables
--------------
group:
to_email_id:
from_email_id:

Dependencies
------------

N/A

Example Playbook
----------------

---
- name: fetch user details
  hosts: all
  tasks:
    - name:

...


License
-------

N/A

Author Information
------------------

IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)


