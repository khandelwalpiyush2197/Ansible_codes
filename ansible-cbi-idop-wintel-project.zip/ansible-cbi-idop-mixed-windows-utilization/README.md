Playbook Name
============

Monitoring Windows Resource Utilization Includes playbooks like:

ansible-cbi-idop-mixed-windows-cpu-utilization.yml
-------------------------------------------------
This playbook extracts the following CPU utilization metrics for a server.
```
Server Name, Version, Domain, Domain member and Domain role
Server Processor Counts
Processor Cores
Processor threads per core
Logical processor
Product Name (Virtualization Type)
Server uptime in Days Hours and Minutes
List the 15 application with High CPU utilization in descending order percentage.
PID's with its respective process names
Users with respective CPU utilization
```
ansible-cbi-idop-mixed-windows-memory-utilization.yml
------------------------------------------------------
This playbook extracts the following Memory utilization metrics for a server.
```
Server Name, Version & Domain
Total Memory in Mb
Product Name (Virtualization Type)
Server uptime in Hours, Days and Minutes
List the 15 application with High Memory utilization in descending order
list of User Profiles
List of sessions with their respective status (Active, Disc)
List of Users with their respective memory usage
```
ansible-cbi-idop-mixed-windows-disk-utilization.yml
--------------------------------------------------
This playbook extracts the following Disk utilization metrics for a server.
```
Server Name, Version, Domain, Domain Member and Domain Role
Product name (Virtualization type)
List of drives with space details, Free space and used Percent.
User profiles with their respective disk utilization
List of Local users
List of files /folders  in non-OS drives with their respective size and owner details.
Based on first 5 steps, the playbook will
```
ansible-cbi-idop-mixed-windows-disk-remediation.yml
--------------------------------------------------

```
Clear the RecycleBin
Clear the C:\Windows\TEMP folder
Clear the C:\Users\<userprofilename>\AppData\Local\Temp folder.
```

ansible-cbi-idop-mixed-windows-disk-optimisation.yml
---------------------------------------------------
Single playbook to call both ansible-cbi-idop-mixed-windows-disk-utilization.yml and ansible-cbi-idop-mixed-windows-disk-remediation.yml

ansible-cbi-idop-mixed-windows-user-profile-deletion.yml
-------------------------------------------------------
This playbook helps to get the details of users and their respective last login details (in days).
```
Server Name, Version & Domain
Product Name (Virtualization Type)
Server uptime in Hours, Days and Minutes
User with last login in Days.
User last login details.
```
Requirements
-----------

N/A

Role Variables
--------------

N/A

Dependencies
------------

N/A

Example Playbook
----------------

```
---
- name: Name of <usecase>
  hosts: all
  tasks:
    - name:

```
License
-------

BSD

Author Information
------------------
IDOP Integration Team
[DL-IT-ACN-IDOP](acnidop@cbrands.com)
