Playbook Name
=============

ansible-cbi-idop-mixed-windows-server-reachability.yml
Monitoring Windows server reachability test playbook will check the server reachability using ping test and executes RDP port and traceroute.

1) Check the server reachability using ping test
2) If ping test is success, playbook executes RDP port on server
3) If ping test is success, playbook executes tracerout on server
4) If ping test is success, proper message is displayed
5) If ping test fails, proper message is displayed

Requirements
-----------

N/A

playbook Variables
--------------

N/A

Dependencies
------------

N/A

command-line
----------------

```
ansible-playbook -i inventory.ini playbook.yml

```
License
-------

N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com) 


