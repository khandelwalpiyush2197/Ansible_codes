Playbook Name
=========
This Ansible playbook is used to perform ping test, retrieve the uptime and latest reboot details on windows server, by this we can get the below information.

           1) TimeGenerated
           2) EventID
           3) UserName
           4) Message
           5) ping results
           6) uptime 

Requirements
------------
NA
Role Variables
--------------
```
NA

```

Dependencies
------------
N/A


Example Playbook
----------------
```
---
- name: Fetching the details of reboots
  hosts: all
  tasks:
    -name: 
```


License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
