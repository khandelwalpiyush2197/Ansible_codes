Playbook  Name
=========
ansible-cbi-idop-mixed-win-playbook-mssql_block_session
=========

The Ansible Playbook can be used to check if any block sessions is in the database
If yes,
   then a mail will be send with csv file with the details like session_id, wait_duration_ms, wait_type, blocking_session_id
else,
   no email will be send]

Requirements
------------
OPENSSH should be configured on the target Windows machine.
Port 22 should be open on firewall so the Ansible server can communicate with Windows Instances.
pymssql needs to be installed on ansible server

Role Variables
--------------
```
mssql_login_user:
mssql_login_password:
to_email_id:
from_email_id:

```

Dependencies
------------
OPENSSH and Port 22 as briefed in requirements.
pymssql python package needs to be installed ansible control node


Example Playbook
----------------
```
- name: block session query
  hosts: all
  gather_facts: false
  vars:
    mssql_login_user:
    mssql_login_password:
    to_email_id:
    from_email_id:
  tasks:
    - name: block session query
```


License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
