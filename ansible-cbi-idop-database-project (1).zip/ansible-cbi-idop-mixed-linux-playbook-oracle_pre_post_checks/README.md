Playbook  Name
=========
ansible-cbi-idop-mixed-win-playbook-oracle_pre_post_checks.yml
=========

The Ansible Playbook can be used to do pre and post checks before and after oracle patching activity. Action can be decided using the varibale and variable value as below
action_to_take == "prechecks"
action_to_take == "posthecks"

Requirements
------------

openssh and service account access to linux server

Role Variables
--------------
```
action_to_take:
to_email_id:
from_email_id:
test_server: ( Any linux server with service account accessibility preverablity ansible server cbigdc-plnxi891)
```

Dependencies
------------
N/A

Example Playbook
----------------
```
- name: oracle pre and post checks
  hosts: all
  roles:
    - oracle_pre_post_checks
```


License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)