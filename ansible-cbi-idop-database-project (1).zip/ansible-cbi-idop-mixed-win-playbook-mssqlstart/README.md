
Playbook  Name
=========
ansible-cbi-idop-mixed-win-playbook-mssqlstart
=========

The Ansible Playbook can be used to check the status of and MSSQLSERVICE and MSSQLSERVICEAGENT on WINDOWS machines and perform remediation. 
Below are three usecases this Playbook can be used to take respective action.
  1. MSSQLSERVER and MSSQLSERVERAGENT are in STOPPED state
  2. MSSQLSERVER and MSSQLSERVERAGENT are in RUNNING state
  3. MSSQLSERVERAGENT is in STOPPED state, MSSQLSERVER is in RUNNING state
 
This playbook is tested on OnPrem Windows Server 2016 only. It can be extended to Cloud Server as well.

Remediation action
When the Playbook is executed, it will perform below action.
  1. MSSQLSERVER and MSSQLSERVERAGENT are in STOPPED state - The Playbook will START both the agents
  2. MSSQLSERVER and MSSQLSERVERAGENT are in RUNNING state - The Playbook will execute and display respective message
  3. MSSQLSERVERAGENT is in STOPPED state, MSSQLSERVER is in RUNNING state - The Playbook will  start the MSSQLSERVERAGENT.

Requirements
------------
OPENSSH should be configured on the target Windows machine.
Port 22 should be open on firewall so the Ansible server can communicate with Windows Instances.

Role Variables
--------------
```
N/A

```

Dependencies
------------
OPENSSH and Port 22 as briefed in requirements.


Example Playbook
----------------
```
N/A
```


License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
