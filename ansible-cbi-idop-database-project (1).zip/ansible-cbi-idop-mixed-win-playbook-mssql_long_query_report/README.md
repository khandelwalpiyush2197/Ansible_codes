Playbook  Name
=========
ansible-cbi-idop-mixed-win-playbook-mssql_long_query_report
=========

The Ansible Playbook can be used to check if any long running querys is in the database
If yes,
   then a mail will be send with csv file with the details like server name, session id, start time, total elapsed time ms, status, command, database name, cpu_time, executing batch, execting statement, query_plan
else,
   no email will be send

Requirements
------------
OPENSSH should be configured on the target Windows machine.
Port 22 should be open on firewall so the Ansible server can communicate with Windows Instances.
pymssql needs to be installed on ansible server

Role Variables
--------------
```
mssql_login_user:
mssql_login_password:
to_email_id:
from_email_id:

```

Dependencies
------------
OPENSSH and Port 22 as briefed in requirements.
pymssql python package needs to be installed ansible control node


Example Playbook
----------------
```
- name: long query report
  hosts: all
  gather_facts: false
  vars:
    mssql_login_user:
    mssql_login_password:
    to_email_id:
    from_email_id:
  tasks:
    - name: long query report
```


License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
