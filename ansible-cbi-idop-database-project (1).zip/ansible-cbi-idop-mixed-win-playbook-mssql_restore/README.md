Playbook  Name
=========
ansible-cbi-idop-mixed-win-playbook-mssql_restore
=========

The Ansible Playbook can be used to databse back up and restore on another server. It takes 3 scenarios
1) If destination mssql version < source mssql version, then execution will stop with proper message
2) On the destination server, it will check the space of mdf and ldf file location with db size name. If db size is more than space available, proper message will be displayed
3) If above both scenarions are fine, the db refresh will happen 
  a) Same source and destination server with different DB name
  b) Different source and destination server with same DB name
  c) Different source and destination server with different DB name
  d) If the DB is already existing with same name, it will replace the existing DB with new DB

Requirements
------------
OPENSSH should be configured on the target Windows machine.
Port 22 should be open on firewall so the Ansible server can communicate with Windows Instances.
pymssql needs to be installed on ansible server
Since pymssql is installed on cbigdc-plnxi891, playbook will be running from this server

Role Variables
--------------
```
mssql_login_user:
mssql_login_password:
mssql_host:
mssql_dest_host:
back_up_folder: 'D:\IDOP-Testing\'
db_name:
```

Dependencies
------------
OPENSSH and Port 22 as briefed in requirements.
pymssql python package needs to be installed ansible control node


Example Playbook
----------------
```
- name: backup and restore
  hosts: all
  gather_facts: false
  vars:
    mssql_login_user:
    mssql_login_password:
    mssql_host:
    mssql_dest_host:
    back_up_folder: 'D:\IDOP-Testing\'
    db_name:
  tasks:
    - name: create backup folder if not exists
      win_file:

```


License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
