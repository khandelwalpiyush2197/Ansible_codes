Playbook  Name
=========
ansible-cbi-idop-mixed-linux-playbook-remove_db_access
=========

The Ansible Playbook can be used to check if any user has access to databse, and status will be updated to worknote and email.remove_access.sh file is placed on the folder and will give the required details.

Requirements
------------


Role Variables
--------------
```
---
folder_name: /nfs/vol3/oracle/remove_access
file_name: remove_access.sh
user_emailid:
to_email_id:
from_email_id:
ticket_number:
```

Dependencies
------------


Example Playbook
----------------
```
- name: Remove DB Access
  hosts: all
  gather_facts: false
  roles:
    - role: remove_db_access
```


License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
