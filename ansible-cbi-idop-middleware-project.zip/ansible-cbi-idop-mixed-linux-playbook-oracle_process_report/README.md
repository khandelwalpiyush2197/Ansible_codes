Playbook Name
=========
ansible-cbi-idop-mixed-linux-playbook-oracle_process_report.yml

This Ansible playbook can be used to collate the below information of all Linux processes for multiple users and write it into a .csv file. The .csv file will contain the following information.

```
           1) Server Name
           2) Operating System Family
           3) Operating System Version
           4) Virtualization type
           5) Process Name
```
The Playbook will be made available to the endusers on AWX (GUI version of Ansible) as a job template. An individual logging into AWX can execute the job template to run the playbook and the Oracle_Services_Status_Report_< user_name>_<ansible_date_time.date>.csv file will be delivered to the requestor's cbrands email address.


Requirements
------------
Access to <Env>AWX job templates to create the services report respectively.
PROD - https://awx.cbrands.com/
DEV - https://dev-awx.cbrands.com/

Playbook Variables
--------------
```
#user_name is a variable, it can take any valid user_name e.g. oracle.
user_name: <valid username>
from_email_id: <valid cbrands email address>
to_email_id: <valid cbrands email address>
```

Dependencies
------------
N/A


Example Playbook
----------------
```
- name: Oracle_Services_Status_Report 
  hosts: all
  become: true
  become_user: root
  gather_facts: true
  vars:
    user_name: oracle
  task:
    - 

```


License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
