Playbook Name
=========
This Ansible role is  used to do the pre and post checks of the middleware servers and gather the report in .csv file,by this we can get the below information.

Date, Host, DC, Environment, LastReboot, Product, Domain, Version, Console_URL, ConsoleURLStatus, FS, InstanceName, Status, ID , LogPath, Process Dump

Requirements
------------
NA
Role Variables
--------------
```
to_email_id:
from_email_id:
action:
```

Dependencies
------------
N/A


Example Playbook
----------------
```
---
- hosts: all
  roles:
    - ansible-cbi-idop-mixed-linux-playbook-middleware_preandpostchecks
  ignore_unreachable: yes
```


License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
