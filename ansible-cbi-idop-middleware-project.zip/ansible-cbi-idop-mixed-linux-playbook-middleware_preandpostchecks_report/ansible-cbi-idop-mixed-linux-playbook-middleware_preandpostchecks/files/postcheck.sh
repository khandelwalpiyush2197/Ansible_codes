#!/bin/bash
##########################################################################
####          PostCheck Script for Information collection             ####
##########################################################################
####            ----- Details -----                                   ####
#### Created on :: 04-Jan-2022                                        ####
#### Server :: To be used on Middleware servers.                      ####
####  -------------------------------------------------------------   ####
#### Changes this script will do ?                                    ####
#### Script wouldn't make any changes to any files/folders            ####
##########################################################################

#=== Setting variables value ===#
Date=`date +"%d-%B-%y"`;
Host=`hostname -f`;
user=oracle
id=`whoami`;
Outputfile=/tmp/PostInfo_$Host"_"$Date".csv"
JdbcOutputFile=/tmp/JDBC_$Host"_"$Date".csv"
Preoutputfile=`ls -lrt /tmp/Info_* | tail -1 |rev|awk '{print $1}'|rev`

#=== Inputs === #
DomainFS="/app/oracle /u02 /u03";
OHSCheck=`ls -lrd /app/oracle/webtier/instances 2>/dev/null`
IGCheck=`ls -lrd /app/entrust/identityguard* 2>/dev/null`
IDQCheck=`ls -lrd /app/informatica/idq/services 2>/dev/null`
OUDCheck=`ls -lrd  /app/oracle/product/middleware/Oracle_OUD 2>/dev/null`
EMPathCheck=`ls -lrd /app/emagent/ 2>/dev/null`
ohsInstancePath="/app/oracle/webtier/instances/instance1/config/fmwconfig/components/OHS/instances/"
OHS_Binary_path="/u01/app/oracle/webtier/wlserver/../ohs/bin/"


## Checking if user is logged in with correct id.
if [[ "$id" == "$user" ]]; then

DomainPath=`find  $DomainFS -iname "domains" -type d 2>/dev/null| egrep -v 'templates|file:|samples'`

## Common Information

    		Osversion=`cat /etc/redhat-release | awk -F "release " '{print $2}'`
			ProcessorCount=`cat /proc/cpuinfo | grep -i processor |wc -l`
			Memory=`free -m | grep "Mem:" |awk -F " " '{print $2}'`
			DC=`hostname -f|awk -F "-" '{print $1}'|sed 's/cbi//g'`
			Uptime=`uptime -s 2>/dev/null`; if [[ -z $Uptime ]] ; then Uptime=`who -b |awk '{print $3" "$4}'`;fi;
			JavaProcess=` ps -ef | egrep -i 'java' | grep -v grep | tr -d '*'|tr -d ','`
			Env=`hostname -f|awk -F "-" '{print $2}'|sed -e 's/\(.\)[^-]*-*/\1/g'`

					if [[ $Env == 'd' || $Env == 'D' ]]
					then
					Environment="Development";
					elif [[ $Env == 'q' || $Env == 'Q' ]]
					then
					Environment="QA";
					elif [[ $Env == 'i' || $Env == 'I' ]]
					then
					Environment="Test";
					elif [[ $Env == 'p' || $Env == 'P' ]]
					then
					Environment="Production";
					fi
						
			echo -e "Date,Host,DC,Environment,OS_version,LastReboot,Product,Domain,Version,Console_URL,ConsoleURLStatus,FS,InstanceName,Precheck Status,Status now,Status change,ID,Heap,LogPath,Process Dump" > $Outputfile ;
			
			
## WebLogic Block ##
## Start of DomainPath "if block" ###

if [ -z "$DomainPath" ]
then
:
#			echo "No Weblogic Domain found under /app/oracle "
else

			DomainList=`find $DomainPath -mindepth 1 -maxdepth 1 2>/dev/null`
			
				for domain in $DomainList
				do
					Console_URL=`cat $domain/bin/stopWebLogic.sh 2>/dev/null| grep -i "admin_url" | grep -i t3 | awk -F "t3://" '{print $2}'| sed 's/"//g'`
					FS=`echo $domain | awk -F "/" '{print "/"$2}'`
					
					cd $domain/config/jdbc 2>/dev/null
					JDBC_List=`ls -l *.xml 2>/dev/null|rev | awk -F " " '{print $1}'|rev`
				

					Instances=`ls -lrt $domain/servers/ 2>/dev/null| grep dr|rev|awk -F " " '{print $1}'|rev`
					
					
					
					BinaryPath=`cat $domain/bin/setDomainEnv.sh 2>/dev/null | grep -w WL_HOME= | grep -v '^#'|awk -F '=' '{print $2}'|sed 's/"//g'`
                    Javahome=`cat $domain/bin/setDomainEnv.sh 2>/dev/null| grep -w JAVA_HOME= | grep -v '{'| sed 's/\t//g'|awk -F '=' '{print $2}'|sed s'/"//g'`
                    WeblogicVersion=`$Javahome/bin/java -cp $BinaryPath/server/lib/weblogic.jar weblogic.version 2>/dev/null| grep -v 'Use' | tr -d '\n' | awk '{print $1" "$2" "$3}'`
					
					### Start of instance for loop ###
						for Instance_list in $Instances
						do
						InstanceLog=`ls -lrd $domain/servers/$Instance_list/logs 2>/dev/null| rev|awk -F " " '{print $1}'|rev`
						InstanceRunning=`ps -ef | grep $Instance_list | grep -v grep`
						Heap=`ps -ef | grep -i $Instance_list |grep -v grep | grep -i xmx | awk -F '-Xms' '{print "Xms"$2}'| awk -F " " '{print $1" "$2}'`
						ID=`ps -ef | grep $Instance_list | grep -v grep|awk '{print $1}' |sort|uniq`
						
							if [[ $Instance_list == "AdminServer" ]]; then
							InstanceLog=`echo $InstanceLog ";" ; cat $domain/scripts/startAdmin.sh 2>/dev/null| grep LOGFILE= `
							fi
							if [[ -z $InstanceRunning ]] ; then
							IStatus="Stopped"
							else
							IStatus="Running"
							fi
							
							ConsoleURLStatus=`timeout 10 curl -o /dev/null -s -w "%{http_code}\n" http://$Console_URL/console/login/LoginForm.jsp`
							
							if [[ -z $ConsoleURLStatus ]]; then
							ConsoleURLStatus=`timeout 10 curl -o /dev/null -s -w "%{http_code}\n" https://$Console_URL/console/login/LoginForm.jsp`
							
							fi
							
							Product="WebLogic";
							
									
							
							PreCheck_Status=`cat  $Preoutputfile|cut -d, -f1-15|grep $Host| grep $Product| grep -w $domain|grep -w $Instance_list | awk -F "," '{print $13}'`
							if [[ $IStatus != $PreCheck_Status ]]; then Status_change=`echo Earlier instance $Instance_list was $PreCheck_Status and now $IStatus.`;fi

							echo $Date,$Host,$DC,$Environment,$Osversion,$Uptime,$Product,$domain,$WeblogicVersion,$Console_URL,$ConsoleURLStatus,$FS,$Instance_list,$PreCheck_Status,$IStatus,$Status_change,$ID,$Heap,$InstanceLog,$JavaProcess >>  $Outputfile ;
							
							unset Status_change; unset PreCheck_Status;
						done
					### End of instance loop ###

				done
				## End of domain "for loop" ##
			
	
fi
### End of WebLogic block 
#------------------------------------

## End of DomainPath "if block" ###





### OHS Instances
#--------------------------------------------------------------
unset Version;unset Heap;unset FS;unset InstanceLog;
Product="Oracle_HTTP_Server";

if [[ -z $OHSCheck ]] ; then
:
#echo "No-OHS Instance";
else

	OHS_Instances=`find $ohsInstancePath -maxdepth 1 -mindepth 1 2>/dev/null`

	for OHSlist in $OHS_Instances
	do 
	Instance_list=`echo $OHSlist|rev|awk -F "/" '{print $1}'|rev`
	OHSStatus=`ps -ef | grep $OHSlist | grep -v grep`
	FS=`echo $OHSlist | awk -F "/" '{print "/"$2}'`
	ID=`ps -ef | grep $OHSlist | grep -v grep|awk '{print $1}' |sort|uniq`

			if [[ -z $OHSStatus ]] ; then
				IStatus="Stopped"
				else
				IStatus="Running"
			fi
		
		OHSLog="/app/oracle/webtier/instances/instance1/servers/$Instance_list/logs"
		InstanceLog=`ls -lrd $OHSLog|rev|awk -F " " '{print $1}'|rev`
		
		OhomePath=`echo $ohsInstancePath| awk -F "webtier" '{print $1"webtier"}'`
		export ORACLE_HOME=$OhomePath
		export LD_LIBRARY_PATH=$ORACLE_HOME/ohs/lib:$ORACLE_HOME/lib:$ORACLE_HOME/oracle_common/ohs/lib:$ORACLE_HOME/oracle_common/lib:$LD_LIBRARY_PATH
		OHS_Version=`$OHS_Binary_path/httpd -version|grep -i version| sed 's/Server version: //g'`
		
		Instances_running_process=`ps -ef | grep httpd | grep -v grep| awk -F " " '{print $8" "$11}'| sort| uniq | awk -F " " '{print $2}'|uniq`
		
		
			PreCheck_Status=`cat  $Preoutputfile|cut -d, -f1-15|grep $Host| grep $Product| grep -w $Instance_list | awk -F "," '{print $13}'`
			if [[ $IStatus != $PreCheck_Status ]]; then Status_change=`echo Earlier instance $Instance_list was $PreCheck_Status and now $IStatus.`;fi

								
		echo $Date,$Host,$DC,$Environment,$Osversion,$Uptime,$Product,$domain,$OHS_Version,$Console_URL,,$FS,$Instance_list,$PreCheck_Status,$IStatus,$Status_change,$ID,$Heap,$InstanceLog,$Instances_running_process >>  $Outputfile ;
		unset Status_change; unset PreCheck_Status;
		
		

	done

fi





#### Other services ####

## Zabbix
#-----------------------------------------
unset Version;unset Heap;unset FS;unset InstanceLog;
Product="Zabbix_Agent";
	Zabbix_process=`ps -ef | grep -i zabbix | grep -v grep`;
	ID=`ps -ef | grep -i zabbix_agent | grep -v grep|awk '{print $1}' |sort|uniq`
	
	if [[ -z $Zabbix_process ]] ; then
		ZabbixStatus="Stopped"
	else
		ZabbixStatus="Running"
	fi
ZabbixVersion=`/usr/sbin/zabbix_agent* --version 2>/dev/null | head -1`
ZabbixLogFile=`cat /etc/zabbix/zabbix_agent*.conf 2>/dev/null| grep -v '#'| grep -v -e '^$' | grep -i LogFile= | awk -F "=" '{print $2}'`
Zname="Zabbix_Agent"

			PreCheck_Status=`cat  $Preoutputfile|cut -d, -f1-15|grep $Host| grep $Product| grep -w $Zname | awk -F "," '{print $13}'`
			if [[ $ZabbixStatus != $PreCheck_Status ]]; then Status_change=`echo Earlier instance $Zname was $PreCheck_Status and now $ZabbixStatus.`;fi

						

echo $Date,$Host,$DC,$Environment,$Osversion,$Uptime,$Product,,$ZabbixVersion,,,,$Zname,$PreCheck_Status,$ZabbixStatus,$Status_change,$ID,$Heap,$ZabbixLogFile,$Zabbix_process >>  $Outputfile ;
unset Status_change; unset PreCheck_Status;

# -- End of Zabbix block -----------------


## Identity guard
#-----------------------------------------
unset Version;unset Heap;unset FS;unset InstanceLog;

Product="Identity_Guard";

if [[ -z $IGCheck ]] ; then
		:
		# echo "Identity manager not found";
		else
	unset Version;unset Heap;unset FS;unset InstanceLog;
	IG_Instances=`ls -lrd /app/entrust/identityguardselfservice /app/entrust/identityguard*/client /app/entrust/apache-tomcat* 2>/dev/null |rev |awk '{print $1}'|rev`
	JavaProcess=`ps -ef | grep -i java| grep -v grep`

		for IGinstances in $IG_Instances
		do
		InstanceName=`echo $IGinstances | awk -F "/" '{print $4}'`
		IGProcess=`ps -ef | grep $IGinstances | grep -v grep`
		FS=`echo $IGinstances | awk -F "/" '{print "/"$2}'`
		ID=`ps -ef | grep $IGinstances | grep -v grep|awk '{print $1}' |sort|uniq`
	

			if [[ -z $IGProcess ]] ; then
				IGStatus="Stopped"
				else
				IGStatus="Running"
			fi
		Heap=`ps -ef | grep -i $IGinstances |grep -v grep | grep -i xmx | awk -F '-Xms' '{print "Xms"$2}'| awk -F " " '{print $1" "$2}'`
		
		
		InstanceLog=`find /app/entrust/$InstanceName -iname "logs" -type d 2>/dev/null`
		
		
		PreCheck_Status=`cat  $Preoutputfile|cut -d, -f1-15|grep $Host| grep $Product|grep -w $InstanceName | awk -F "," '{print $13}'`
			if [[ $IGStatus != $PreCheck_Status ]]; then Status_change=`echo Earlier instance $InstanceName was $PreCheck_Status and now $IGStatus.`;fi

							
			
		
		echo $Date,$Host,$DC,$Environment,$Osversion,$Uptime,$Product,,$Version,,,$FS,$InstanceName,$PreCheck_Status,$IGStatus,$Status_change,$ID,$Heap,$InstanceLog,$JavaProcess >>  $Outputfile ;
		unset Status_change; unset PreCheck_Status;

		done

	
	
fi
# -- End of Identity Guard block --------------


## Informatica
#-----------------------------------------
unset Version;unset Heap;unset FS;unset InstanceLog;

Product="Informatica_IDQ";



if [[ -z $IDQCheck ]] ; then
		:
		# echo "IDQ services not found";
		else
  
	#### Informatica IDQ Analyst service	
	
	unset Version;unset Heap;unset FS;unset InstanceLog;
	InstanceName="IDQ_Analyst_Service"
	IDQ_Analyst_Service=`ps -ef | grep AnalystService | grep -v grep`

	ID=`ps -ef | grep AnalystService| grep -v grep|awk '{print $1}' |sort|uniq`
	FS=`echo $IDQ_Analyst_Service | awk -F "/" '{print "/"$2}'`
	Heap=`ps -ef | grep -i AnalystService |grep -v grep | tr ' ' '\n' |egrep -i 'xms|xmx' | tr '\n' ' '|sed 's/^-//g'`
	InstanceLog=`ps -ef | grep AnalystService | grep -v grep | awk -F "DServiceLogDirectory=" '{print $2}' | awk '{print $1}'`
	IDQProcess=`ps -ef | grep -i idq | grep -v grep | tr -d ',' | tr -d '*'`
	
	#Config file for Port# /app/informatica/idq/tomcat/temp/AS_DQ_DEV/conf/server.xml
	#Port being used for Analyst instance 6110
	URL=`echo https://$Host:6110//analyst/web.isp/login`
	Version=`curl -vk $URL  2>&1 /dev/null| grep -i version | awk -F 'id=' '{print $2}'| sed 's/>/ /g'`


	if [[ -z $IDQ_Analyst_Service ]] ; then
				IDQ_Analyst_Service_status="Stopped"
				else
				IDQ_Analyst_Service_status="Running"
	fi
	
	
			PreCheck_Status=`cat  $Preoutputfile|cut -d, -f1-15|grep $Host| grep $Product|grep -w $InstanceName | awk -F "," '{print $13}'`
			if [[ $IDQ_Analyst_Service_status != $PreCheck_Status ]]; then Status_change=`echo Earlier instance $InstanceName was $PreCheck_Status and now $IDQ_Analyst_Service_status.`;fi

			#$PreCheck_Status,$IStatus,$Status_change
							
			
	
	echo $Date,$Host,$DC,$Environment,$Osversion,$Uptime,$Product,,$Version,,,$FS,$InstanceName,$PreCheck_Status,$IDQ_Analyst_Service_status,$Status_change,$ID,$Heap,$InstanceLog,$IDQProcess >>  $Outputfile ;
	unset Status_change; unset PreCheck_Status;
	
	
#### Informatica IDQ Admin service	
    unset Version;unset Heap;unset FS;unset InstanceLog;
	InstanceName="IDQ_Administrator_Service"
	IDQ_Administrator_Service=`ps -ef | grep /app/informatica/idq/services/AdministratorConsole | grep -v grep`

	ID=`ps -ef | grep /app/informatica/idq/services/AdministratorConsole | grep -v grep|awk '{print $1}' |sort|uniq`
	FS=`echo $IDQ_Administrator_Service | awk -F "/" '{print "/"$2}'`
	Heap=`ps -ef | grep -i /app/informatica/idq/services/AdministratorConsole |grep -v grep | tr ' ' '\n' |egrep -i 'xms|xmx' | tr '\n' ' '|sed 's/^-//g'`
	InstanceLog=`ps -ef | grep /app/informatica/idq/services/AdministratorConsole | grep -v grep | awk -F "DServiceLogDirectory=" '{print $2}' | awk '{print $1}'`
	IDQProcess=`ps -ef | grep -i idq | grep -v grep | tr -d ',' | tr -d '*'`
	
	#Config file for Port# /app/informatica/idq/tomcat/temp/_AdminConsole/conf/server.xml
	#Port being used for Admin 6100
	URL=`echo https://$Host:6100/administrator/`
	Version=`curl -vk $URL  2>&1 /dev/null| grep -i version | awk -F 'id=' '{print $2}'| sed 's/>/ /g'`
	
	if [[ -z $IDQ_Administrator_Service ]] ; then
				IDQ_Administrator_Service_status="Stopped"
				else
				IDQ_Administrator_Service_status="Running"
	fi
	
		PreCheck_Status=`cat  $Preoutputfile|cut -d, -f1-15|grep $Host| grep $Product|grep -w $InstanceName | awk -F "," '{print $13}'`
		if [[ $IDQ_Administrator_Service_status != $PreCheck_Status ]]; then Status_change=`echo Earlier instance $InstanceName was $PreCheck_Status and now $IDQ_Administrator_Service_status.`;fi

		#$PreCheck_Status,$IStatus,$Status_change
							
		
	
	echo $Date,$Host,$DC,$Environment,$Osversion,$Uptime,$Product,,$Version,,,$FS,$InstanceName,$PreCheck_Status,$IDQ_Administrator_Service_status,$Status_change,$ID,$Heap,$InstanceLog,$IDQProcess >>  $Outputfile ;		
	unset Status_change; unset PreCheck_Status;
	
fi

#End of Informatica block
#--------------------------------------------




## OUD block
#-----------------------------------------
unset Version;unset Heap;unset FS;unset InstanceLog;
Product="OUD";
SHost=`hostname -s`

if [[ -z $OUDCheck ]] ; then
		:
		# echo "OUD services not found";
		else
  
	#### directory_instance
	
	
	InstanceName="Directory_instance"
	directory_instance_Service=`ps -ef | grep directory_instance | grep -v grep`

	ID=`ps -ef | grep directory_instance| grep -v grep|awk '{print $1}' |sort|uniq`
	FS=`echo $directory_instance_Service | awk -F "/" '{print "/"$2}'`
	Heap=`ps -ef | grep -i directory_instance |grep -v grep | tr ' ' '\n' |egrep -i 'xms|xmx' | tr '\n' ' '|sed 's/^-//g'`
	InstanceLog=`ls -lrd /u02/oracle/logs/oud/$SHost/directory_instance*  |rev| awk '{print $1}'|rev`
	OUDProcess=`ps -ef | grep -i oud | grep -v grep | tr -d ',' | tr -d '*'`
	
	

	if [[ -z $directory_instance_Service ]] ; then
				directory_instance_Service_status="Stopped"
				else
				directory_instance_Service_status="Running"
	fi
	
		PreCheck_Status=`cat  $Preoutputfile|cut -d, -f1-15|grep $Host| grep $Product| grep -w $InstanceName | awk -F "," '{print $13}'`
		if [[ $directory_instance_Service_status != $PreCheck_Status ]]; then Status_change=`echo Earlier instance $InstanceName was $PreCheck_Status and now $directory_instance_Service_status.`;fi

		#$PreCheck_Status,$IStatus,$Status_change
							

	echo $Date,$Host,$DC,$Environment,$Osversion,$Uptime,$Product,,$Version,,,$FS,$InstanceName,$PreCheck_Status,$directory_instance_Service_status,$Status_change,$ID,$Heap,$InstanceLog,$OUDProcess >>  $Outputfile ;
	unset Status_change; unset PreCheck_Status;
	
	
#### Proxy_instance	
    unset Version;unset Heap;unset FS;unset InstanceLog;
	InstanceName="Proxy_instance"
	proxy_instance_Service=`ps -ef | grep proxy_instance | grep -v grep`

	ID=`ps -ef | grep proxy_instance| grep -v grep|awk '{print $1}' |sort|uniq`
	FS=`echo $proxy_instance_Service | awk -F "/" '{print "/"$2}'`
	Heap=`ps -ef | grep -i proxy_instance |grep -v grep | tr ' ' '\n' |egrep -i 'xms|xmx' | tr '\n' ' '|sed 's/^-//g'`
	InstanceLog=`ls -lrd /u02/oracle/logs/oud/$SHost/proxy_instance*  |rev| awk '{print $1}'|rev`
	OUDProcess=`ps -ef | grep -i oud | grep -v grep | tr -d ',' | tr -d '*'`
	
	

	if [[ -z $proxy_instance_Service ]] ; then
				proxy_instance_Service_status="Stopped"
				else
				proxy_instance_Service_status="Running"
	fi
	
		PreCheck_Status=`cat  $Preoutputfile|cut -d, -f1-15|grep $Host| grep $Product| grep -w $InstanceName | awk -F "," '{print $13}'`
		if [[ $proxy_instance_Service_status != $PreCheck_Status ]]; then Status_change=`echo Earlier instance $InstanceName was $PreCheck_Status and now $proxy_instance_Service_status.`;fi

		#$PreCheck_Status,$IStatus,$Status_change
	
	echo $Date,$Host,$DC,$Environment,$Osversion,$Uptime,$Product,,$Version,,,$FS,$InstanceName,$PreCheck_Status,$proxy_instance_Service_status,$Status_change,$ID,$Heap,$InstanceLog,$OUDProcess >>  $Outputfile ;
	unset Status_change; unset PreCheck_Status;
	
fi

#End of OUD block
#--------------------------------------------



## AAMS Agent
#----------------------------------------------
unset Version;unset Heap;unset FS;unset InstanceLog;

AAMS_PathCheck=`ls -lrd /app/rimini/ 2>/dev/null`
Product="AAMS_Agent";
InstanceName="AAMS_Agent"

if [[ -z $AAMS_PathCheck ]] ; then
:
#		echo "AAAMS agent not found";
		else
		
		AAMS_Process=`ps -ef | grep -i rimini | grep -i console | grep -v grep`
		ID=`ps -ef | grep -i rimini | grep -i console| grep -v grep|awk '{print $1}' |sort|uniq`
	
			if [[ -z $AAMS_Process ]] ; then
				AamsAgent_Status="Stopped"
				else
				AamsAgent_Status="Running"
			fi
		unset Version
		#echo $Date,$Host,$DC,$Environment,$Uptime,$Product,,$Version,,,$FS,$InstanceName,$AamsAgent_Status,$ID,$InstanceLog,$AAMS_Process >>  $Outputfile ;
		
		PreCheck_Status=`cat  $Preoutputfile|cut -d, -f1-15|grep $Host| grep $Product| grep -w $InstanceName | awk -F "," '{print $13}'`
		if [[ $AamsAgent_Status != $PreCheck_Status ]]; then Status_change=`echo Earlier instance $InstanceName was $PreCheck_Status and now $AamsAgent_Status.`;fi

		#$PreCheck_Status,$IStatus,$Status_change
	
		
		echo $Date,$Host,$DC,$Environment,$Osversion,$Uptime,$Product,,$Version,,,$FS,$InstanceName,$PreCheck_Status,$AamsAgent_Status,$Status_change,$ID,$Heap,$InstanceLog,$AAMS_Process >>  $Outputfile ;
	
fi
#--------------------------------------------------



## EM Agent
#----------------------------------------------
unset Version;unset Heap;unset FS;unset InstanceLog;

Product="EM_Agent";
InstanceName="EM_Agent"

if [[ -z $EMPathCheck ]] ; then
:
#		echo "EM Agent not found";
		else
		
		EM_Process=`ps -ef | grep emagent| egrep -v 'grep|perl'`
		ID=`ps -ef | grep emagent | grep -v grep|awk '{print $1}' |sort|uniq`
	
			if [[ -z $EM_Process ]] ; then
				EMAgent_Status="Stopped"
				else
				EMAgent_Status="Running"
			fi
		unset Version
		
		PreCheck_Status=`cat  $Preoutputfile|cut -d, -f1-15|grep $Host| grep $Product| grep -w $InstanceName | awk -F "," '{print $13}'`
		if [[ $EMAgent_Status != $PreCheck_Status ]]; then Status_change=`echo Earlier instance $InstanceName was $PreCheck_Status and now $EMAgent_Status.`;fi

		#$PreCheck_Status,$IStatus,$Status_change
							
		
		echo $Date,$Host,$DC,$Environment,$Osversion,$Uptime,$Product,,$Version,,,$FS,$InstanceName,$PreCheck_Status,$EMAgent_Status,$Status_change,$ID,$Heap,$InstanceLog,$EM_Process >>  $Outputfile ;
		unset Status_change; unset PreCheck_Status;
		
fi
#--- End of EM Agent block

#echo -e "Hello,\n PFA PreScript result from server - `hostname` as on Date - `date` "|mailx -a $Outputfile -a $JdbcOutputFile -s "Files from `hostname`" swatantra.mishra@cbrands.com 2>/dev/null

cat $Outputfile

#echo -e "Hello,\nPFA PreScript result from server - `hostname` as on Date - `date` "|mailx -a $Outputfile -s "Files from `hostname`" -r "Swatantra<swatantra.mishra@cbrands.com>" swatantra.mishra@cbrands.com 2>/dev/null


else

	echo -e "\nERROR :: Please login with "$user" id and then run this script.\n";
	exit 1;
fi




