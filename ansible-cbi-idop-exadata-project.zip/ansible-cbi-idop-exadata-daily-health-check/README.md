Playbook Name
============

main.yml
------------------------------------------------------
This playbook performs the daily health checks.
```
The script is placed on /nfs/vol3/Daily_health_checkup_Script location of tne1dbadm01 server.
The script will be called with oracle user for running the script. A mail will be triggered to Exadata DL with the attched HTML report.
Script name: CBI_DHC_SCRIPT.sh 
```
Requirements
-----------

N/A

Role Variables
--------------

N/A

Dependencies
------------

N/A

Example Playbook
----------------

```
---
- name: Daily health checks
  hosts: all
  tasks:
    - name:

```
License
-------

N/A

Author Information
------------------
IDOP Integration Team
[DL-IT-ACN-IDOP](acnidop@cbrands.com)