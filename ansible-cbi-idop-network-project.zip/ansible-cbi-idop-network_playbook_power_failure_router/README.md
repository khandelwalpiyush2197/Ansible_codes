Playbook Name
============

ansible-cbi-idop-network_playbook_power_failure_router.yml
-------------------------------------------------
This playbook helps to have initial troubleshooting steps for power failure issues in router. Troubleshooting steps include:
    1) show environment all
    2) show logging | in FRU
    3) show logging | in PS

Requirements
-----------

ssh connectivity to routers from ansible server and AWX dev and production environment.

Role Variables
--------------

```
device_name:

```
which is derived from service now ticket.

```
ansible_connection= network_cli
ansible_network_os= ios
```
which needs to be added as part of host variables

Dependencies
------------

N/A

Example Playbook
----------------

```
---
- name: Power failure troubleshoot for router
  hosts: all
  gather_facts: false

```
License
-------

N/A

Author Information
------------------
IDOP Integration Team
[DL-IT-ACN-IDOP](acnidop@cbrands.com)