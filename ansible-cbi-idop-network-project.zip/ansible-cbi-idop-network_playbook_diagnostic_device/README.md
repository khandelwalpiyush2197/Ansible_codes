Playbook Name
============

ansible-cbi-idop-network_playbook_power_diagnostic_device.yml
-------------------------------------------------
This playbook helps to if any network device incident recieved in ATR, it will run below commands and update in worknotes.
    1) show version | in uptime
    2) show environment all
    3) show interface info
    4) sh int | in line|error|CRC|drops|reset
    5) show log 
    6) show log | in FRU

Requirements
-----------

ssh connectivity to routers from ansible server and AWX dev and production environment.

Role Variables
--------------

```
ansible_connection= network_cli
ansible_network_os= ios
```
which needs to be added as part of host variables

Dependencies
------------

N/A

Example Playbook
----------------

```
---
- name: Diagnostic device down
  hosts: all
  gather_facts: false

```
License
-------

N/A

Author Information
------------------
IDOP Integration Team
[DL-IT-ACN-IDOP](acnidop@cbrands.com)
