Playbook Name
ansible-cbi-idop-network_playbook_health_check.yml
This playbook helps to have basic health checks for all the network devices

Requirements
ssh connectivity to all devices from ansible server and AWX dev and production environment using service account.

Role Variables
to_email_id:
from_email_id:

ansible_connection= network_cli
ansible_network_os= ios
which needs to be added as part of host variables

Dependencies
N/A

Example Playbook
---
- name: Health check network devices
  hosts: all
  gather_facts: false

License
N/A

Author Information
IDOP Integration Team DL-IT-ACN-IDOP