Description
=========

This tasks creates the shared mailbox associated to the user. Get details of already existed mailbox, if already exist it update the ticket and stop there . Using exchange commands it will connect with windows server and creates sharedmailbox.
Once created it will set permission and update ticket notes .
SUCCESS: shared mailbox created successfully and provided permissions.
FAILURE: Shared mailbox already exist

Requirements
------------

Server cetificates

Variables
--------------

user: 
owner: 
mailbox:
domain:
ticket_id:
userlist:

Dependencies
------------

NA

Example Playbook
----------------

---
- hosts: localhost
  gather_facts: false
  tasks:

License
-------

N/A

Author Information
------------------

IDOP Integration Team
[DL-IT-ACN-IDOP](acnidop@cbrands.com)