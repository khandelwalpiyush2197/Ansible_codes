Description
=========

This tasks gives permission to already existed shared mailbox associated to the user. Get details of already existed mailbox, Give send as permission to user. 
Using exchange commands it will connect with windows server and give permission.
It will set permission and update ticket notes .
SUCCESS: Provided permissions successfully to delegates.

Requirements
------------

Server cetificates

Variables
--------------

user:  
mailbox:
domain:
ticket_id:
userlist:

Dependencies
------------

NA

Example Playbook
----------------

---
- hosts: localhost
  gather_facts: false
  tasks:

License
-------

N/A

Author Information
------------------

IDOP Integration Team
[DL-IT-ACN-IDOP](acnidop@cbrands.com)