Role Name
=========

add_remove_rule_instanceid
This role is used to add/remove INGRESS/EGRESS rules on Security group, taking instance id as an input.

ADD INGRESS/EGRESS rules
this role will check if rule already exists in any of the security group attached to it, if yes then stop execution.
If the rules doesnt exists in any of the existing security group then it will create a new security rule with name ADHOC-<instance_id> and add the required rule to this newly created security group and attach the instance to this group.
Once the ADHOC security group exists further addition will happen to this security group alone.
Back up of the rules will be taken to S3 after each update, if update failed rules will be reverted back to previous rules.

REMOVE INGRESS/EGRESS rules
Check if rule exists in ADHOC security group, if exists then remove that rule from ADHOC security group]
Else stop execution stating rule doesnot exists.
Back up of the rules will be taken to S3 after each update, if update failed rules will be reverted back to previous rules.

We have made sure if any instance have more than one NIC card the playbook ends execution.
Requirements
------------

community.aws needs to be added in collections/requirements.yml

Role Variables
--------------

```
---
instance_id: 
region:
add_rule: true/false
ingress_rule: true/false
source_bucket:
rule_list:
   - { cidr_ip: , ports: , proto:  }
   - { group_id: , ports: , proto: }
```
| variable Name | true  | false |
| -------------| ------------- | ------------- |
| ingress_rule | INGRESS rule will be updated  | EGRESS rule will be updated |
| add_rule  | Rules will be added  | Rule will be revoked |

source_bucket is a role variable for bucket name for saving all the rules present in the security groups.Before and after updating the security group. The permissions required for the bucket is "WRITE" permissions.

rule_list is the variable for list of rules to be added
cidr_ip: source_ip, single ip per line for example: 10.167.22.223/32
ports: ports for opening, it can be either single port or port range, example: 80, 80-90
proto: protocol example: tcp, udp etc.
group_id: id of any security group to be added in rule

Dependencies
------------

N/A

Example Playbook
----------------

```
---
- name: ADD REMOVE rule in security group using Instance ID
  hosts: localhost
  roles:
    - add_remove_rule_instanceid
```

License
-------

N/A

Author Information
------------------

IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
