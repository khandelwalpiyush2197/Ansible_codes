#!/usr/bin/env python

import yaml
import json
import sys

security_group_dict = {}
try:
        json_input = json.loads(sys.argv[1])
        security_group_dict['vpc_id'] = json_input['vpc_id']
        security_group_dict['name'] = json_input['group_name']
        if 'description' in json_input:
                security_group_dict['description'] = json_input['description']
        ingress_rules = []
        egress_rules = []
        for ip_permission in json_input['ip_permissions']:
                for ip_range in ip_permission['ip_ranges']:
                        ip_range_rule = {}
                        ip_range_rule['proto'] = ip_permission['ip_protocol']
                        if ip_permission['ip_protocol'] == '-1':
                                ip_range_rule['ports'] = -1
                        else:
                                from_port = ip_permission['from_port']
                                to_port = ip_permission['to_port']
                                if from_port == to_port:
                                        ip_range_rule['ports'] = from_port
                                else:
                                        ip_range_rule['from_port'] = from_port
                                        ip_range_rule['to_port'] = to_port
                        ip_range_rule['cidr_ip'] = ip_range['cidr_ip']
                        if 'description' in ip_range:
                                ip_range_rule['rule_desc'] = ip_range['description']
                        ingress_rules.append( ip_range_rule )
                for prefix in ip_permission['prefix_list_ids']:
                        prefix_rule = {}
                        prefix_rule['proto'] = ip_permission['ip_protocol']
                        if ip_permission['ip_protocol'] == '-1':
                                prefix_rule['ports'] = -1
                        else:
                                from_port = ip_permission['from_port']
                                to_port = ip_permission['to_port']
                                if from_port == to_port:
                                        prefix_rule['ports'] = from_port
                                else:
                                        prefix_rule['from_port'] = from_port
                                        prefix_rule['to_port'] = to_port

                        prefix_rule['prefix_list_id'] = prefix['prefix_list_id']
                        if 'description' in prefix:
                                prefix_rule['rule_desc'] = prefix['description']
                        ingress_rules.append( prefix_rule )
                for user_id_group_pairs in ip_permission['user_id_group_pairs']:
                        user_id_group_pair_rule = {}
                        user_id_group_pair_rule['proto'] = ip_permission['ip_protocol']
                        if ip_permission['ip_protocol'] == '-1':
                                user_id_group_pair_rule['ports'] = -1
                        else: 
                                from_port = ip_permission['from_port']
                                to_port = ip_permission['to_port']
                                if from_port == to_port:
                                        user_id_group_pair_rule['ports'] = from_port
                                else:
                                        user_id_group_pair_rule['from_port'] = from_port
                                        user_id_group_pair_rule['to_port'] = to_port
                        user_id_group_pair_rule['group_id'] = user_id_group_pairs['group_id']
                        if 'description' in user_id_group_pairs:
                                user_id_group_pair_rule['rule_desc'] = user_id_group_pairs['description']
                        ingress_rules.append( user_id_group_pair_rule )
        
        security_group_dict['rules'] = ingress_rules
        
        for ip_permission_egress in json_input['ip_permissions_egress']:
                for ip_range in ip_permission_egress['ip_ranges']:
                        ip_range_rule = {}
                        ip_range_rule['proto'] = ip_permission_egress['ip_protocol']
                        if ip_permission_egress['ip_protocol'] == '-1':
                        	ip_range_rule['ports'] = -1
                        else:
                                from_port = ip_permission_egress['from_port']
                                to_port = ip_permission_egress['to_port']
                                if from_port == to_port:
                                        ip_range_rule['ports'] = from_port
                                else:
                                        ip_range_rule['from_port'] = from_port
                                        ip_range_rule['to_port'] = to_port
                        ip_range_rule['cidr_ip'] = ip_range['cidr_ip']
                        if 'description' in ip_range:
                               ip_range_rule['rule_desc'] = ip_range['description']
                        egress_rules.append( ip_range_rule )
                for prefix in ip_permission_egress['prefix_list_ids']:
                        prefix_rule = {}
                        prefix_rule['proto'] = ip_permission_egress['ip_protocol']
                        if ip_permission_egress['ip_protocol'] == '-1':
                                prefix_rule['ports'] = -1
                        else:
                                from_port = ip_permission_egress['from_port']
                                to_port = ip_permission_egress['to_port']
                                if from_port == to_port:
                                        prefix_rule['ports'] = from_port
                                else:
                                        prefix_rule['from_port'] = from_port
                                        prefix_rule['to_port'] = to_port

                        prefix_rule['prefix_list_id'] = prefix['prefix_list_id']
                        if 'description' in prefix:
                                prefix_rule['rule_desc'] = prefix['description']
                        egress_rules.append( prefix_rule )
                for user_id_group_pairs in ip_permission_egress['user_id_group_pairs']:
                        user_id_group_pair_rule = {}
                        user_id_group_pair_rule['proto'] = ip_permission_egress['ip_protocol']
                        if ip_permission_egress['ip_protocol'] == '-1':
                                user_id_group_pair_rule['ports'] = -1
                        else:
                                from_port = ip_permission_egress['from_port']
                                to_port = ip_permission_egress['to_port']
                                if from_port == to_port:
                                        user_id_group_pair_rule['ports'] = from_port
                                else:
                                        user_id_group_pair_rule['from_port'] = from_port
                                        user_id_group_pair_rule['to_port'] = to_port
                        user_id_group_pair_rule['group_id'] = user_id_group_pairs['group_id']
                        if 'description' in user_id_group_pairs:
                                user_id_group_pair_rule['rule_desc'] = user_id_group_pairs['description']
                        egress_rules.append( user_id_group_pair_rule )
                        
        security_group_dict['rules_egress'] = egress_rules

#	if 'tags' in json_input:
#		security_group_dict['tags'] = json_input['tags']
        print( json.dumps(security_group_dict))
except Exception as e:
        print( e )
        sys.exit(1)