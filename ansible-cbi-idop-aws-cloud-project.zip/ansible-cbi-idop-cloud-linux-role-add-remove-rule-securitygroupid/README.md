Role Name
=========

add_remove_rule_groupid
Add/remove INGRESS/EGRESS rules from the security group taking security groupID as an input parameter.

ADD INGRESS/EGRESS rules
Copy the existing security group configuration to an s3 bucket.
As a pre requiste check if the requested rule exists in the security group, if the rules exists then no action taken.
If the requested rule doesn't exist, the playbook runs and update the security group with new rule.
If the playbook is successful in adding rules to security group, then the updated configuration will be saved to s3 bucket.
If the playbook is failed in adding therules to security group, then the playbook will revert the rules to the previous configuration.
 
REMOVE INGRESS/EGRESS rules
Copy the existing security group configuration to an s3 bucket.
As a pre requiste check if the rule exists. If yes, then the requested rule will be removed from the security group.
If the rule doesn’t exist, then no action taken.
If the playbook is successful in removing rules from security group, then the updated configuration will be saved to s3 bucket.
If the update fails, the playbook will revert to the previous configuration.

Requirements
------------

community.aws needs to be added in collections/requirements.yml

Role Variables
--------------

```
---
region: 
groupid: 
add_rule: <true/false>
ingress_rule: <true/false>
source_bucket: idop-bucket-dev
rule_list:
   - { cidr_ip: , ports: , proto: }
   - { group_id: , ports: , proto: }
```
| variable Name | true  | false |
| -------------| ------------- | ------------- |
| ingress_rule | INGRESS rule will be updated  | EGRESS rule will be updated |
| add_rule  | Rules will be added  | Rule will be revoked |



Dependencies
------------

N/A

Example Playbook
----------------

```
---
- name: ADD or REMOVE rules from Security group with Security ID
  hosts: localhost
  roles:
     - add_remove_rule_groupid
```
License
-------

N/A

Author Information
------------------

IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
