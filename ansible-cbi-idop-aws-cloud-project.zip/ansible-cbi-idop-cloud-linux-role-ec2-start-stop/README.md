Role Name
=========

ansible-cbi-idop-cloud-linux-role-ec2-start-stop
This role helps to start or stop EC2 based on the requirement.

Requirements
------------

Proper connectivity to AWS and credentials.

Role Variables
--------------

instances_list_start:
              - {instance: <instance_id>,region: <region_value>}
instances_list_stop:
              - {instance: <instance_id>,region: <region_value>}

Either instances_list_start or instances_list_stop list based on the requirement to start or stop Instances
just provide instance_id and region_value with whichever instance needs to be started/stopped

Dependencies
------------

N/A

Example Playbook
----------------

```
---
- name: Stop/Start EC2 Instances
  hosts: localhost
  roles:
    - ec2_stop_start
```
License
-------

BSD

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
