Role Name
=========

These playbooks help us to automate the creation and deletion of AWS instance based snapshot(AMI).

ansible-cbi-idop-cloud-mixed-ec2-instance-ami_registration.yml
--------------------------------------------------------------

The above playbook will take instance id, region, number of retention days and requestor's email id as required input parameters from the end user.
This playbook will take these as input parameters, create instance based snapshot and update the snapshot(AMI) with tag key: Retention and value: <retention_date>.The playbook will send a success/failure email notification to  he requestor. 


ansible-cbi-idop-cloud-mixed-ec2-instance-ami_de-registration.yml
----------------------------------------------------------------

The above playbook will be scheduled daily, the playbooks scans the entire AWS account for snapshot(AMI) tags key: Retention and value: <retention_date>. The playbook compares the retention_date with the present day date and creates a list of snapshots(AMI) to be deleted.The playbook deletes these snapshots and send an email notification with the list of snapshots deleted to the cloud team.


Requirements
------------

AWS permissions to create/delete snapshots.
AWS permissions to add/modify tags.
community.aws and community.general needs to be added in requirements.yml in collections folder.

Role Variables
--------------

ansible-cbi-idop-cloud-mixed-ec2-instance-ami_registration.yml
--------------------------------------------------------------

instance_id: <instance_id>
region: <region>
sender_email_address: <sender's emailid>
requestor_email_address: <requestor's email id>
retention_days: <retention_days>


retention_days can take any numeric value, the playbook will take numeric value, calculates the retention_date accordingly and update the snapshot tag.

ansible-cbi-idop-cloud-mixed-ec2-instance-ami_de-registration.yml
-----------------------------------------------------------------

region: <region>
sender_email_address: <sender's emailid>
requestor_email_address: <requestor's email id>

Dependencies
------------

N/A

Example Playbook
----------------

ansible-cbi-idop-cloud-mixed-ec2-instance-ami_registration.yml
```
- hosts: localhost
  vars:
    instance_id: <instance_id>
    region: <region>
    sender_email_address: <sender's emailid>
    requestor_email_address: <requestor's email id>
    retention_days: <retention_days>
  tasks:
```
ansible-cbi-idop-cloud-mixed-ec2-instance-ami_de-registration.yml
```
---
- hosts: localhost
  vars:
    region: <region>
    sender_email_address: <sender's emailid>
    requestor_email_address: <requestor's email id>
  tasks:

License
-------

N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
