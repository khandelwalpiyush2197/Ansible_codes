Role Name
=========
ansible-cbi-idop-cloud-linux-role-alb-register-deregister
This Ansible role can be used to register and deregister an ec2 instances from the ALB.

Requirements
------------
The ApplicationLoadBalancer and Ec2 Instances should be exist in AWS

Role Variables
--------------
```
register_info:
  - { register_target_group_arn: "ALB_ARN",register_region: <ALB_region>,register_instance_id: <instance_id> }
deregister_info:
  - { de_register_region: <ALB_region>,deregister_instance_id: <instance_id> }
```

Dependencies
------------
N/A


Example Playbook
----------------
```
- name: reg-dereg-instances-ALB
  hosts: localhost
  roles:
    - reg-dereg-instances-ALB

```


License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
