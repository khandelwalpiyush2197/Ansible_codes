Role Name
=========
ansible-cbi-idop-rds-playbook-Server_start_stop_restart
This Ansible role can be used to perform START,STOP,RESTART for bulk VMware servers

Requirements
------------
Port 443 should be open for the Ansible server to communicate with the vcenter.

Role Variables
--------------
```
vcenter_list: [ ]
vcenter_username: < vcenter_username >
vcenter_password: < vcenter_password >
virtualmachine_list: [ ]
state: 

```

Dependencies
------------
N/A

Example Playbook
----------------

```
---
- name: Server status change
  hosts: all
  include:
    - roles: ansible-cbi-idop-rds-role-Server_start_stop_restart

```

License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
