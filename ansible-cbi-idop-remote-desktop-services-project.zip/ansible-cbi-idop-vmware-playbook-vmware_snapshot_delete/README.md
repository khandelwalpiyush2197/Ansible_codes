
Playbook Name
============

ansible-cbi-idop-vmware-playbook-snapshot_delete.yml
-------------------------------------------------
This playbook can be used to delete a VMWare Virtual Machine Snapshot. This is a scheduled activity and does not need any manual intervention. Every time the playbook is triggered, it will perform a scan on all existing Vcenters and prepare a list of snapshots to be deleted.
 
Naming Convention for Snapshot which will be deleted is  - <vmname>-SNAPSHOT-EXPIRY-DATE-<RETENTION_DATE>-time

The Playbook will then perform a DELETE operation on all the Snapshots which has an expiry date of "todays_date" in the name of the snapshot.


Requirements
-----------

pyvmomi package needs to be installed on ansible control node to execute the vmware modules.

Role Variables
--------------

```
 vcenter_list:
 vcenter_username:
 vcenter_password:
 from_email_id : itacnwintel@cbrands.com
 to_email_id : itacnwintel@cbrands.com
 ansible_python_interpreter: /usr/bin/python3

```

Dependencies
------------

N/A

Example Playbook
----------------

```
---
- name: Delete snapshot schedule
  hosts: all
  gather_facts: false
  roles:
    - vmware_snapshot_delete


```
License
-------

N/A

Author Information
------------------
IDOP Integration Team
[DL-IT-ACN-IDOP](acnidop@cbrands.com)

