Playbook Name
=========
Ansible-cbi-idop-mixed-windows-Hosts_maintenance_mode.yml
This Ansible Playbook can be used to put hosts and their VM's into maintenance mode and send mail to user with attached report with the below information.

           1) Host Name
           2) Virtual Machine name
           3) Status

Requirements
------------
Port 443 should be open for the Ansible server to communicate with the vcenter.

Role Variables
--------------
```
    vcenter_hostname:
    esxi_hostname:
    to_email_id:
    from_email_id:
    vcenter_username:
    vcenter_password:
```

Dependencies
------------
N/A

Example Playbook
-------------
---
- name: host list check
  hosts: all
  tasks:
    - name: Sample Playbook
----------------
```
```


License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
