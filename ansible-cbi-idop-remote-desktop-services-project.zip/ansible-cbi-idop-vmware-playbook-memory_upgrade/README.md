Playbook Name
============

ansible-cbi-idop-vmware-playbook-memory_upgrade.yml
-------------------------------------------------
This playbook helps to increase the memory of the vm host.This playbook sends email alert for every actions, before power off, if update fails and on sucessful MEMORY upgrade.


Requirements
-----------

pyvmomi package needs to be installed on ansible control node to execute the vmware modules.

Role Variables
--------------

```
vcenter: "{{ lookup('env', 'VMWARE_HOST') }}"
user: "{{ lookup('env', 'VMWARE_USER') }}"
password: "{{ lookup('env', 'VMWARE_PASSWORD') }}"
user_hostname: 
increase_GB: 
to_email_id: 
from_email_id:

```

Dependencies
------------

N/A

Example Playbook
----------------

```
---
- name: MEMORY upgrade for vmware
  hosts: all
  gather_facts: false

```
License
-------

N/A

Author Information
------------------
IDOP Integration Team
[DL-IT-ACN-IDOP](acnidop@cbrands.com)