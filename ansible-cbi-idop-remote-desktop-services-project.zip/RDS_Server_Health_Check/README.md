
Playbook Name
=========
Remote_Desktop_Services_Health_Check.yml
The Ansible playbook can be used to fetch the RDS servers health check report from RDS machines. This playbook is intended only on below two servers. The connectivity is already in place for below servers to fetch the details from other RDS servers.

CBITDC-PRDSI971
CBIGDC-PRDSI972

This Playbook is intended to work seamlessy on Windows Servers 2019OS  versions. IDOP team had shared an existing Powershell Script which is used to perform similar activity, IDOP team has wrapped this PowerShell script with Ansible (as wrapper) and made available as Job Template in Dev-AWX. This report creation will be scheduled, the report will be sent to the RDS mailbox twice a day or a team member  can run the job template and generate the health check report on ADHOC basis via AWX GUI.
If the playbook execution is successful, the health check report will be emailed to the requestor 
If the playbook execution is failed, relevant message will be displayed in the AWX console.

Requirements
------------

1. Access to AWX Console (Dev & PROD)
2. The Powershell scipt should be copied into both remote machines to the location /temp/script/
3. Service Credentials to schedule a report.
4. Elevated previleges to the below RDS machines, so the report gets generated successfully.



Playbook Variables
--------------

from_email_id: dlitacnvdirds@cbrands.com
to_email_id: dlitacnvdirds@cbrands.com
username: cwc\<username>
script_location: <C:/temp/Script>
script_name: <RDPServerHealthCheck_v1.0.1.ps1>

```

Dependencies
------------
1. AWX access to the team
2. The PowerShell script should be placed in the c:\temp\script\ location and the report generated from the PS should be placed in the same location where the script resides on both the servers to ensure the Playbook is successful.


License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
