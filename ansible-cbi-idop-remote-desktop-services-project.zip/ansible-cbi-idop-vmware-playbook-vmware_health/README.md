Role Name
=========

This Role helps to genrate complete health report of the vmware on scheduel basis, html report will be emailed to the vmware team.

Requirements
------------

NA

Role Variables
--------------

vcenter_list: [ ]
username:
password:
to_email:
from_email:

Dependencies
------------

NA

Example Playbook
----------------

```
---
- name: VMware health check status
  hosts: all
  gather_facts: false
  roles:
    - vmware_health


License
-------

NA

Author Information
------------------

IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
