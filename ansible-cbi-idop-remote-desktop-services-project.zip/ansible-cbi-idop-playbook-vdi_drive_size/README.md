Role Name
=========

disk-usage
This ansible role can be used to generate csv report with below details and send mail to user with attached file.
1. Hostname
2. VM
3. GuestName
4. Datastore
5. CapacityGB
6. DiskFreeSpace
7. Total VMFSconsumed

Requirements
------------

N/A

Role Variables
--------------
vcenter_list: [ ]
vcenter_username: 
vcenter_password: 
to_email:
from_email:

Dependencies
------------

N/A

Example Playbook
----------------

- name: C drive space report
  gather_facts: false
  hosts: all
  roles:
   - disk-usage

License
-------

N/A

Author Information
------------------

IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)

