Role Name
=========
ansible-cbi-idop-mixed-windows-remote-desktop-services-user-cal-report
This Ansible role can be used to genereated report on RDS server with below the details and send mail to user with attached report.
           1) Server Name
           2) Server OS
           3) Server OS Version
           4) Total Licenses
           5) Avaliable Licenses
           6) Issued Licenses
           7) User CAL
           8) Issued Date
           9) Expired Date 

Requirements
------------
Open SSH to be installed and port 22 should be open for the Ansible server to communicate with the node server.

Role Variables
--------------
```
from_email_id: < email_id >
to_email_id: < email_id >

```

Dependencies
------------
N/A


Example Playbook
----------------
```
---
- hosts: all
  roles:
    - Licensemanager
```


License
-------
N/A

Author Information
------------------
IDOP Integration Team

[DL-IT-ACN-IDOP](acnidop@cbrands.com)
