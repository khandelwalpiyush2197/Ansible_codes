Playbook Name
============

ansible-cbi-idop-vmware-playbook-snapshot_creation.yml
-------------------------------------------------
This playbook helping to creation of Snapshot of the vm host.vm host name is taken as input and it will scan on all every existing Vcenter and find the associate Vcenter. on taking the retention days required for the snapshot and considering available freespace on the datastore, the snapshot will be created with name as "{{ virtualmachine_name }}-EXPIRY-DATE-{{ retention }}-{{ ansible_date_time.time }}".
This playbook sends email alert for every actions, before snapshot creation and sends email alert after once craetion of snapshot successfull.


Requirements
-----------

pyvmomi package needs to be installed on ansible control node to execute the vmware modules.

Role Variables
--------------

```
 vcenter_list:
 vcenter_username:
 vcenter_password:
 virtualmachine_name:
 retention_days :
 from_email_id : itacnwintel@cbrands.com
 to_email_id :
 ansible_python_interpreter: /usr/bin/python3

```

Dependencies
------------

N/A

Example Playbook
----------------

```
---
- hosts: all
  vars:
    vcenter_list:
    vcenter_username:
    vcenter_password:
    virtualmachine_name:
    retention_days :
    from_email_id : itacnwintel@cbrands.com
    to_email_id :
    ansible_python_interpreter: /usr/bin/python3
  tasks:


```
License
-------

N/A

Author Information
------------------
IDOP Integration Team
[DL-IT-ACN-IDOP](acnidop@cbrands.com)
